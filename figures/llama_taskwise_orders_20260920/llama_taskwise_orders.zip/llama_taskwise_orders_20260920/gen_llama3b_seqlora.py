from plot_taskwise import draw
if __name__ == '__main__':
    draw('Llama-3.2-3B', seqlora_only=True)

